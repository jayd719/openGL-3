/* 
 * Description: testing on mesh object model
 * Adopted from reference resource
 * HBF
 */
#include <GL/glut.h>
#include <string.h>

#include "Mesh.hpp"

GLsizei winWidth = 600, winHeight = 600;

GLint objType = 0;
char str[100];

Mesh * meshObj;
Mesh * meshObj1;
Mesh * meshObj2;

void lineSegment(float x1, float y1, float z1, float x2, float y2, float z2) {
	glBegin(GL_LINES);
	glVertex3f(x1, y1, z1);
	glVertex3f(x2, y2, z2);
	glEnd();
}

void display(void) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glColor3f(1.0, 0.0, 0.0);
	lineSegment(-4, 0, 0, 4, 0, 0); /* x-axis in red */
 	glColor3f(0.0, 1.0, 0.0);
	lineSegment(0, -4, 0, 0, 4, 0); /* y-axis in green */
	glColor3f(0.0, 0.0, 1.0);
	lineSegment(0, 0, -4, 0, 0, 4); /* z-axis in blue */

	glColor3f(1.0, 1.0, 0.0);

	if (objType == 0) {
		meshObj->draw();
	}
	else if (objType == 1) {
		meshObj1->draw();
	}
	else if (objType == 2) {
		meshObj2->draw();
	}

	glFlush();
	glutSwapBuffers();
}


void init(void) {
	glClearColor(0.0, 0.0, 0.0, 1.0);
	/* Setup 3D view */
	glMatrixMode(GL_PROJECTION);
	gluPerspective(
	 40.0,  /* field of view in degree */
	 1.0,   /* aspect ratio */
	 1.0,   /* Z near */
	 15.0   /* Z far */
	);
	glMatrixMode(GL_MODELVIEW);
	gluLookAt(4.0, 6.0, 10.0, /* eye is at (0,0,5) */
	          0.0, 0.0, 0.0,  /* center is at (0,0,0) */
	          0.0, 0.0, 1.0   /* up is in positive Y direction */
    );

	meshObj = new Mesh("BARN.3VN");
	meshObj1 = new Mesh("BUCK.3VN");
	meshObj2 = new Mesh("PAWN.3VN");
}


void mainMenuFcn(GLint menuOption) {
	objType = menuOption;
	glutPostRedisplay();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB );
	glutInitWindowPosition(50, 100);
	glutInitWindowSize(winWidth, winHeight);
	glutCreateWindow("Mesh object model");

    init();
	glutDisplayFunc(display);         /* Send graphics to display window. */

	glutCreateMenu(mainMenuFcn);      /* Create main pop-up menu */
	glutAddMenuEntry("Barn", 0);
	glutAddMenuEntry("Buck", 1);
	glutAddMenuEntry("Pawn", 2);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	
	glutMainLoop();
}
